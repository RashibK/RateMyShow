// MyAnimeList Client_ID and REDIRECT_URI
export const MAL_CLIENT_ID = "db72b0c4364bb89f8c4bc7991b734bee";
export const MAL_REDIRECT_URI = browser.identity.getRedirectURL();
