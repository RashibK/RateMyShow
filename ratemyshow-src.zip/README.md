# RateMyShow — Firefox Extension

**RateMyShow** is a Firefox extension that lets users rate shows from supported streaming sites and sync those ratings to external services. This is the full source code required for Mozilla Add-ons (AMO) review.

---

## 📁 Project Structure

- `src/` – JavaScript source code for the extension
- `public/manifest.json` – The original extension manifest used by Vite during build
- `vite.config.*.js` – Vite configurations for different entry points (popup, background, etc.)
- `package.json` & `package-lock.json` – Project dependencies and scripts
- `tailwind.config.js`, `postcss.config.mjs`, `eslint.config.js` – Build and lint configurations
- `README.md` – This file
- `LICENSE` – Project license

---

## 🔧 Build Instructions

This extension uses [Vite](https://vitejs.dev/) and JavaScript for bundling and building.

### 1. Install dependencies

```bash
npm install
